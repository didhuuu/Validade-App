# Validade-
Aplicativo de controle de vencimentos.
Fluxo: Criar lista → código de barras → descrição → validade → quantidade → finalizar → relatório.
O APK é gerado automaticamente pelo GitHub Actions.
